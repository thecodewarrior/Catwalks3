package mcjty.lib.varia;

public class SecurityTools {

    // @todo
//    public static boolean isAdmin(EntityPlayer player) {
//        return player.capabilities.isCreativeMode || MinecraftServer.getServer().getConfigurationManager().getOppedPlayers().func_183026_b(player.getGameProfile());
//    }

}
