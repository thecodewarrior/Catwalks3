package mcjty.lib.gui.layout;

public enum HorizontalAlignment {
    ALIGH_LEFT,
    ALIGN_RIGHT,
    ALIGN_CENTER
}
