package mcjty.lib.gui.layout;

public enum VerticalAlignment {
    ALIGN_TOP,
    ALIGN_BOTTOM,
    ALIGN_CENTER
}
