package mcjty.lib.gui.layout;

/**
 * This interface represents a layout hint which is used by some of the layouts.
 */
public interface LayoutHint {
}
