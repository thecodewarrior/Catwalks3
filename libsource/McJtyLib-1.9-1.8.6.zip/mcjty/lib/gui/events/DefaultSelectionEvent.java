package mcjty.lib.gui.events;

import mcjty.lib.gui.widgets.Widget;

public class DefaultSelectionEvent implements SelectionEvent {
    @Override
    public void select(Widget parent, int index) {

    }

    @Override
    public void doubleClick(Widget parent, int index) {

    }
}
