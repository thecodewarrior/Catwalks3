/**
 * Created by Elec332 on 17-10-2015.
 */
@API(apiVersion = McJtyLib.VERSION, owner = McJtyLib.OWNER, provides = McJtyLib.PROVIDES)
package mcjty.lib;

import net.minecraftforge.fml.common.API;