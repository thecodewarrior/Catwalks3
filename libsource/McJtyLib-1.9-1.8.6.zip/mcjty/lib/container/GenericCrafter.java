package mcjty.lib.container;

public interface GenericCrafter {

    void craftItem();

}
